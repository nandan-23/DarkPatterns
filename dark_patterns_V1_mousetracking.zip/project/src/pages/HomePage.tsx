import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { startTracking } from '../utils/mouseTracker';
import TrackingControls from '../components/TrackingControls';

export default function HomePage() {
  const navigate = useNavigate();

  const handleStartShopping = () => {
    startTracking();
    navigate('/category/health');
  };

  return (
    <div className="max-w-4xl mx-auto py-12">
      <div className="bg-white rounded-2xl shadow-xl p-8">
        <h1 className="text-4xl font-bold text-purple-900 mb-6 text-center">
          Welcome to DarkPatternsV1
        </h1>
        
        <div className="space-y-6">
          <div className="bg-purple-50 p-6 rounded-xl">
            <h2 className="text-2xl font-semibold text-purple-900 mb-4">Your Task</h2>
            <p className="text-lg text-gray-700 leading-relaxed">
              You need to purchase <span className="font-semibold">Ashwagandha Powder</span> from the Health category. 
              You have a budget of <span className="font-semibold text-green-600">₹5,000</span>.
            </p>
          </div>

          <div className="bg-blue-50 p-6 rounded-xl">
            <h2 className="text-2xl font-semibold text-blue-900 mb-4">Shopping Guidelines</h2>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>First, choose your Ashwagandha powder from the Health category</li>
              <li>After selecting your Ashwagandha powder, you can spend the remaining budget on any products from:</li>
              <ul className="ml-8 mt-2 space-y-1 list-disc">
                <li>Health Products</li>
                <li>Food Products</li>
                <li>Cosmetics Products</li>
              </ul>
            </ul>
          </div>

          <div className="bg-green-50 p-6 rounded-xl">
            <h2 className="text-2xl font-semibold text-green-900 mb-4">Budget Tracking</h2>
            <p className="text-lg text-gray-700">
              Your remaining budget will be displayed at the top of the page as you shop.
            </p>
          </div>

          <button 
            onClick={handleStartShopping}
            className="block w-full bg-purple-600 text-white text-center py-4 rounded-xl text-lg font-semibold hover:bg-purple-700 transition-colors"
          >
            Start Shopping
          </button>
        </div>
      </div>
      <TrackingControls />
    </div>
  );
}