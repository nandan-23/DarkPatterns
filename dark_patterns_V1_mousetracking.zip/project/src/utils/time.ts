// Utility functions for time-related operations
export const getCurrentTimestamp = (): string => {
  return new Date().toISOString();
};

export const getMicrosecondTime = (): number => {
  return performance.now();
};

export const calculateTimecode = (startTimeMs: number): number => {
  return (getMicrosecondTime() - startTimeMs) / 1000;
};