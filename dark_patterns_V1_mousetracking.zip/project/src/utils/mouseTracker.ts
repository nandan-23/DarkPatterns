import { getCurrentTimestamp, getMicrosecondTime, calculateTimecode } from './time';
import { formatCSVRow, downloadCSV } from './csv';

interface CartInteraction {
  action: 'add' | 'remove';
  productId: string;
  productName: string;
  timestamp: string;
  timecode: number;
}

let cartInteractions: CartInteraction[] = [];
let startTime: number | null = null;

export const startTracking = () => {
  startTime = getMicrosecondTime();
};

export const getTimecode = (): number => {
  if (!startTime) return 0;
  return calculateTimecode(startTime);
};

export const trackCartInteraction = (
  action: 'add' | 'remove',
  productId: string,
  productName: string
) => {
  if (!startTime) return;

  cartInteractions.push({
    action,
    productId,
    productName,
    timestamp: getCurrentTimestamp(),
    timecode: getTimecode()
  });
};

export const exportToCSV = () => {
  const headers = ['Action', 'Product ID', 'Product Name', 'Timestamp', 'Timecode (seconds)'];
  
  const rows = [
    formatCSVRow(headers),
    ...cartInteractions.map(interaction => formatCSVRow([
      interaction.action,
      interaction.productId,
      interaction.productName,
      interaction.timestamp,
      interaction.timecode.toFixed(6) // 6 decimal places for microsecond precision
    ]))
  ];

  const csvContent = rows.join('\n');
  const filename = `cart-interactions-${getCurrentTimestamp()}.csv`;
  
  downloadCSV(csvContent, filename);
};