export const products = [
  // Health Category
  {
    id: 'h1',
    name: 'Zandu Ashwagandha Gold Plus',
    description: 'Made with Gold, Ashwagandha, Safed Musli',
    price: 350,
    category: 'Health',
    image: 'https://m.media-amazon.com/images/I/413BRSn4cSL._SX300_SY300_QL70_FMwebp_.jpg',
    details: 'Premium Ashwagandha supplement enhanced with gold and safed musli for overall wellness.'
  },
  {
    id: 'h2',
    name: 'HealthKart HK Vitals Ashwagandha',
    description: 'Ashwagandha Extract 500mg',
    price: 350,
    category: 'Health',
    image: 'https://m.media-amazon.com/images/I/61d6lG8aw+L._SX522_.jpg',
    details: 'High-potency Ashwagandha extract for stress relief and immunity.'
  },
  {
    id: 'h3',
    name: 'Himalaya Ashvagandha Tablets',
    description: 'General Wellness & Stress Relief Tablets',
    price: 304,
    category: 'Health',
    image: 'https://m.media-amazon.com/images/I/61eNW65rU0L._SX522_.jpg',
    details: 'Natural Ashvagandha tablets for stress relief and general wellness.'
  },
  {
    id: 'h4',
    name: 'Trivang Natural Ashwagandha Powder',
    description: '100% Natural Ashwagandha Powder',
    price: 350,
    category: 'Health',
    image: 'https://m.media-amazon.com/images/I/61OSG7XWgxL._SX522_.jpg',
    details: 'Pure and natural Ashwagandha powder for holistic wellness.'
  },
  {
    id: 'h5',
    name: 'Ayuvya Immunity Tablets',
    description: 'Natural Immunity Booster',
    price: 449,
    category: 'Health',
    image: 'https://n2.sdlcdn.com/imgs/k/x/u/ayuvya-Tablets-For-Immunity-Pack-SDL787753027-1-536b1.jpg',
    details: 'Natural immunity boosting tablets with traditional herbs.'
  },
  {
    id: 'h6',
    name: 'Ayuvya Body Ache Oil',
    description: 'Natural Pain Relief Oil',
    price: 299,
    category: 'Health',
    image: 'https://n1.sdlcdn.com/imgs/k/w/6/ayuvya-Oil-For-Body-Ache-SDL083588056-1-54b27.png',
    details: 'Therapeutic oil for body ache and pain relief.'
  },
  {
    id: 'h7',
    name: 'VITALIX Instant Health Mix',
    description: 'Complete Health Mix Powder',
    price: 599,
    category: 'Health',
    image: 'https://arbanox.com/cdn/shop/files/Vitalix_3.png?v=1717398706&width=493',
    details: 'Instant health mix powder for daily nutrition and wellness.'
  },
  {
    id: 'h8',
    name: 'Healthspan Metabolism Boost Combo',
    description: 'Probiotic for Weight & Immunity',
    price: 999,
    category: 'Health',
    image: 'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcQU09_LYHl506EOG0LyGoAEcDy3vO2VGGk0QRPgDYDI_3XdsGNGi7MCo_6rNeF4iKcf6DWJ1jFbv9DLD7b6Lqzy1GQkCife_a0_WbuY274XKdapFpg3oE03Yg&usqp=CAE',
    details: 'Complete metabolism boost combo with probiotics for weight management and immunity.'
  },
  {
    id: 'h9',
    name: 'Gut Health Superfoods Mix',
    description: 'Nutritional Superfood Blend',
    price: 749,
    category: 'Health',
    image: 'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcS5TWAJd-y1mJhQl_qdmUltDByJ7UlFxOPz1rfR4GQSsgxnnODXTL4vA89w10D2Hh318LftsNmE448qIFBwaSi6_dohsUS25B2ny1_I3v48DyOwhB7iJ6WD&usqp=CAE',
    details: 'Comprehensive superfood mix for optimal gut health.'
  },
  {
    id: 'h10',
    name: 'Trubiotics Probiotic Gummies',
    description: 'Sugar-Free Probiotic Gummies',
    price: 599,
    category: 'Health',
    image: 'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcRZobmHajZNesHier5UfJPqJ91TxI22pWM-lEo05dyRMdcatj9gJ8LKtyWfJ-OrokkPv40f3Zarf-Of4tsv5j79Qr6q5JjIHwg3cYnYuDfhlIe0qIGRKVk-bg&usqp=CAE',
    details: 'Sugar-free probiotic gummies with prebiotics & vitamin D3 for digestive health.'
  },
  {
    id: 'h11',
    name: 'The Body Temple Probiotics',
    description: '50 Billion CFU Probiotics',
    price: 849,
    category: 'Health',
    image: 'https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcRcIPb4h7AuvrFrQPZCRlGZC50PnIz3Jf3x0GrOhixWg_4G8tcldlhhebIwWZkc9tLcjCwZKaZZ3q78GbHIDVMRB_Oy-G-zMGtiSMAl9hS9OZPGb9CVKoEG7AM&usqp=CAE',
    details: 'High-strength probiotics for detox, gut health & immunity.'
  },
  {
    id: 'h12',
    name: 'Seniorz Daily Health Booster',
    description: 'Health Syrup for Seniors',
    price: 599,
    category: 'Health',
    image: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRG9Tzovw78MySapMstBKCj1PeyW5LxwXctNteDnxwAFyxOF6UZHfpQWlxf9Uh2NV_gVyL9KbeQuAnZwewLdn99-jF0MiJDv_wFGzcsKo0u-xfC6PQGLUF22g&usqp=CAE',
    details: 'Daily health booster syrup for elderly immunity & energy (450ml).'
  },

  // Food Category
  {
    id: 'f1',
    name: 'Premium Dry Fruits & Nuts',
    description: 'Healthy Snack Food High in Protein',
    price: 499,
    category: 'Food',
    image: 'https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcTaepiPHIobQ9p9YMAnF3mMhnmbyPhNs-rO0ofZZGowVgOjm_9QUwar3Gx5AmdvnBnaIJU51Jkl_v5MUPJ-uPzw338We3BBv2E0wmJeX08&usqp=CAE',
    details: 'Premium quality mixed dry fruits and nuts, perfect for healthy snacking.'
  },
  {
    id: 'f2',
    name: 'Timeless Food Chana Garlic Papad',
    description: 'Handmade Rajasthani Special Papad',
    price: 299,
    category: 'Food',
    image: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcTtDXwQT-CONJjFcD1h0vDkOCEElA98piledHFm9fd9oItKGh4cOZKCD9em4tyHnr-TJDZg-2U-nI8j_dcF7816KU1Gt3AGuIk3WzCHiI4ao9_jhYWa2lT7&usqp=CAE',
    details: 'Traditional Rajasthani handmade papad with chana and garlic flavor, 800g pack.'
  },
  {
    id: 'f3',
    name: 'Parle Milano Cookies',
    description: 'Premium Choco Chip Cookies',
    price: 149,
    category: 'Food',
    image: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRGaQhIXdfYB4Pz7y0FZG3Tjvk7xT64GDEvDXKcLAZ9JwnjNHWp2Rxbwe7WaF4Sp66Dg7pduo0jm1FHRwrDmjCl0TDrUOYrnyuwbk1nnFQ-_Z4ndbVbEDi6SQ&usqp=CAE',
    details: 'Delicious chocolate chip cookies from Parle Milano.'
  },
  {
    id: 'f4',
    name: 'Britannia Good Day Chunkies',
    description: 'Chocolate Chip Cookies',
    price: 99,
    category: 'Food',
    image: 'https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcTnUtomKaFPxBeM_C5GJqvept_dpkXhTdTt1JgX6zsxr9szxazSsWvYx6Mfws2y-k2MDClzAhjEUx4dG3j-zdX2ixOchxAqrL6ZNvWhiTHXock00N8sbEsdW_Th&usqp=CAE',
    details: 'Crunchy chocolate chip cookies, 100g pack.'
  },
  {
    id: 'f5',
    name: 'Amul Chocolate Cookies',
    description: 'Premium Chocolate Cookies',
    price: 129,
    category: 'Food',
    image: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRt5Co-2cr4M12CsBxeiHSJhGL-W0GyS1gyikQdipSjaE4mnaYwoh8GjPToFtuZ_DgArLeAYwPSCGDMQdJpCxzJoEdH15Ku8rdisKcLzEXdcy9TSrN1CMcs&usqp=CAE',
    details: 'Rich chocolate flavored cookies from Amul.'
  },
  {
    id: 'f6',
    name: 'Amul Happy Birthday Chocolate',
    description: 'Special Birthday Pack Milk Chocolate',
    price: 199,
    category: 'Food',
    image: 'https://cdnaz.plotch.io/image/upload/w_551/C/V/PLO8eKtpFr1727322462_996c5760150f30acedcf61776ea9a98150d816ab5496971ad055446c8259fe74.jpg',
    details: 'Special birthday pack milk chocolate bar from Amul.'
  },
  {
    id: 'f7',
    name: 'Amul Lite Spread',
    description: 'Low Fat Milk Spread',
    price: 159,
    category: 'Food',
    image: 'https://cdnaz.plotch.io/image/upload/w_551/C/V/PLOBwj7kM41727322462_adefee187f5356d0ec55bec3c2647952a305f13602f42c62a82af5186bae271a.jpg',
    details: 'Healthy low-fat milk spread for daily use.'
  },
  {
    id: 'f8',
    name: 'Amul High Aroma Cow Ghee',
    description: 'Pure Cow Ghee 200ml',
    price: 249,
    category: 'Food',
    image: 'https://cdnaz.plotch.io/image/upload/w_551/C/V/PLO2XDcKYx1727322449_01d54ee17a3f6232aafa3fa7a1ca0396b143408751eae53ab4cb2011f6668b22.jpg',
    details: 'Premium quality cow ghee with high aroma, 200ml jar.'
  },
  {
    id: 'f9',
    name: 'Amul Condensed Milk',
    description: 'Sweet Condensed Milk',
    price: 139,
    category: 'Food',
    image: 'https://cdnaz.plotch.io/image/upload/w_551/C/V/PLO3NeRAWE1727322463_8905aec4d9e2f2e9c9b65e330b153acc25c1d34394e70bca632f37a37ee5d19d.jpg',
    details: 'Sweet condensed milk perfect for desserts and beverages.'
  },
  {
    id: 'f10',
    name: 'Amul Short Bread Cookies',
    description: 'Classic Short Bread Cookies',
    price: 119,
    category: 'Food',
    image: 'https://cdnaz.plotch.io/image/upload/w_551/C/V/PLOEMVDsHJ1727322460_c565ad2337aea06ec9dc8b018b368fae8afa2ae0bf983130231009206116e774.jpg',
    details: 'Traditional short bread cookies with rich buttery taste.'
  },
  {
    id: 'f11',
    name: 'Amul Lassi',
    description: 'Traditional Yogurt Drink 1L',
    price: 179,
    category: 'Food',
    image: 'https://cdnaz.plotch.io/image/upload/w_551/C/V/PLOs90HXNY1727334091_a2ba1e885664ea59f87ca93ed277f1e5ed16d123da8107746b4ba47abf70ade5.jpg',
    details: 'Refreshing traditional yogurt drink, 1 liter pack.'
  },
  {
    id: 'f12',
    name: 'Amul Fruit & Nut Chocolate',
    description: 'Premium Chocolate with Fruits & Nuts',
    price: 169,
    category: 'Food',
    image: 'https://cdnaz.plotch.io/image/upload/w_551/C/V/PLOmcOVAwf1727322456_7e05e04cf6bedb7c86cb19c2a554a36d3e050040161f49fe2c20bc1f38582fb1.jpg',
    details: 'Rich milk chocolate loaded with fruits and nuts, 150g.'
  },

  // Cosmetics Category
  {
    id: 'c1',
    name: 'Beardo Activated Charcoal Face Wash',
    description: 'Deep Cleansing Face Wash for Men',
    price: 270,
    category: 'Cosmetics',
    image: 'https://m.media-amazon.com/images/I/51zjarOxA4L._SY741_.jpg',
    details: 'Deep cleansing face wash with activated charcoal for men - 200ml.'
  },
  {
    id: 'c2',
    name: "POND'S Men Energy Bright Face Wash",
    description: 'Brightening Face Wash for Men',
    price: 220,
    category: 'Cosmetics',
    image: 'https://m.media-amazon.com/images/I/510wyhhk4oL._SX569_.jpg',
    details: 'Energizing and brightening face wash for men - 100g.'
  },
  {
    id: 'c3',
    name: 'NIVEA MEN Fresh Active Deodorant',
    description: '48 Hours Deodorant',
    price: 203,
    category: 'Cosmetics',
    image: 'https://m.media-amazon.com/images/I/41zHdcSgDPL._SX569_.jpg',
    details: 'Long-lasting fresh active deodorant for men.'
  },
  {
    id: 'c4',
    name: 'Nivea Men Dark Spot Reduction Creme',
    description: 'Dark Spot Reduction Face Cream',
    price: 278,
    category: 'Cosmetics',
    image: 'https://m.media-amazon.com/images/I/51NYSJRXJ6L._SX569_.jpg',
    details: 'Face cream for men that helps reduce dark spots.'
  },
  {
    id: 'c5',
    name: 'Maybelline Fit Me Concealer',
    description: 'Liquid Concealer Makeup',
    price: 499,
    category: 'Cosmetics',
    image: 'https://images-cdn.ubuy.co.in/657ef18f889dcf31c918b38f-maybelline-fit-me-liquid-concealer.jpg',
    details: 'Professional liquid concealer for natural coverage.'
  },
  {
    id: 'c6',
    name: 'Forest Essentials Cheek Tint',
    description: 'Noor Nikhaar Satin Cheek Tint Khubani',
    price: 1195,
    category: 'Cosmetics',
    image: 'https://img.forestessentialsindia.com/pub/media/catalog/product/2/1/21286_satin_cheek_tint_noor_nikhaar_khubani_5g_product_display_1.jpg',
    details: 'Luxury satin cheek tint for a natural glow.'
  },
  {
    id: 'c7',
    name: 'Rare Beauty Highlighter',
    description: 'Positive Light Silky Touch Highlighter',
    price: 899,
    category: 'Cosmetics',
    image: 'https://cdn.fynd.com/v2/falling-surf-7c8bb8/fyprod/wrkr/products/pictures/item/free/resize-w:780/000000000494273790/5y6po9D89-000000000494273790_1.png',
    details: 'Silky smooth highlighter for a natural glow.'
  },
  {
    id: 'c8',
    name: 'Elle 18 Foundation',
    description: 'Lasting Glow Foundation',
    price: 299,
    category: 'Cosmetics',
    image: 'https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQryiZmhGwIH8eftZY89HrM8tZoQ8gk1o4XC176l8avA_yksRV7ml1tYNyBxOVI6AROx30xKiSv4ACoK1mUqe5iLB4e0q67qt7xuW6OGRNhk5QU73COQKyHLA&usqp=CAE',
    details: 'Long-lasting foundation for a natural glow.'
  },
  {
    id: 'c9',
    name: 'Kay Beauty Foundation',
    description: 'Hydrating Foundation',
    price: 1199,
    category: 'Cosmetics',
    image: 'https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcQv2qZD-fHtyp5qr8ZJz8J1Wi6gezhxvtomQHJ0ShbXScCkAP8xddYpVee6wXT-FkchrPS3B98kaknMJLUNUj-pQxsEwT1uEVSaArJ2j7sCMBXne94dLb4xqw&usqp=CAE',
    details: 'Hydrating foundation for all-day wear.'
  },
  {
    id: 'c10',
    name: 'Character Pro Eyeshadow',
    description: 'Eyes Pro Eyeshadow Palette',
    price: 799,
    category: 'Cosmetics',
    image: 'https://www.souqalbuhair.com/wp-content/uploads/2024/05/3592490371021-768x768.webp',
    details: 'Professional eyeshadow palette with multiple shades.'
  },
  {
    id: 'c11',
    name: 'Lotus Makeup Eyeshadow',
    description: 'Ecostay Velvet Eye Shadow Evo',
    price: 399,
    category: 'Cosmetics',
    image: 'https://www.souqalbuhair.com/wp-content/uploads/2024/02/806360522011.webp',
    details: 'Long-lasting velvet eyeshadow in Orchid Fresh shade.'
  },
  {
    id: 'c12',
    name: 'Biotique Massage Oil',
    description: 'Avocado Stress Relief Body Massage Oil',
    price: 299,
    category: 'Cosmetics',
    image: 'https://www.souqalbuhair.com/wp-content/uploads/2024/03/8904352005152.webp',
    details: 'Ayurvedic body massage oil with avocado, 200ml.'
  }
] as const;

export const getRandomProduct = () => {
  return products[0];
};

export const getProductsByCategory = (category: string) => {
  return products.filter(product => product.category === category);
};

export const getProductById = (id: string) => {
  return products.find(product => product.id === id);
};