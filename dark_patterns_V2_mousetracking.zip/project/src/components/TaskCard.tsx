import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Product } from '../types';

interface TaskCardProps {
  product: Product;
  budget: number;
}

export default function TaskCard({ product, budget }: TaskCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-2xl overflow-hidden">
      <div className="relative">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-72 object-cover"
        />
        <div className="absolute top-4 right-4 bg-blue-600 text-white px-4 py-2 rounded-full">
          Budget: ${budget.toFixed(2)}
        </div>
      </div>
      <div className="p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Your Task</h2>
        <p className="text-gray-600 mb-4">
          Today's challenge is to purchase this {product.category.toLowerCase()} item:
        </p>
        <div className="bg-gray-50 p-4 rounded-lg mb-6">
          <h3 className="text-xl font-semibold text-gray-900">{product.name}</h3>
          <p className="text-gray-600 mt-2">{product.description}</p>
          <p className="text-lg font-bold text-blue-600 mt-2">
            ${product.price.toFixed(2)}
          </p>
        </div>
        <Link
          to={`/product/${product.id}`}
          className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg flex items-center justify-center space-x-2 hover:bg-blue-700 transition-colors"
        >
          <span>Proceed to Product</span>
          <ArrowRight className="h-5 w-5" />
        </Link>
      </div>
    </div>
  );
}