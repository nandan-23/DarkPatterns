const phrases = [
  'i want this',
  'i have money',
  'i need this',
  'this is useful',
  'take my money',
  'i will use this'
];

export const generateCaptchaText = (): string => {
  const randomIndex = Math.floor(Math.random() * phrases.length);
  return phrases[randomIndex];
};