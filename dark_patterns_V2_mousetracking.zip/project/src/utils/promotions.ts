// Use product ID to generate consistent values
const hashString = (str: string) => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash);
};

export const getPromotionalValues = (productId: string) => {
  const hash = hashString(productId);
  
  // Use hash to determine consistent values
  const discount = 45 + (hash % 31); // Range: 45-75
  const stock = 1 + (hash % 5); // Range: 1-5
  const isDiscountType = hash % 2 === 0; // Consistently choose between discount/stock
  
  return {
    discount,
    stock,
    isDiscountType
  };
};

// Health category promotions - including more Ashwagandha products
const promotionalHealthIds = ['h1', 'h3', 'h4', 'h7', 'h9', 'h11', 'h12'];

// Food category promotions - expanded selection
const promotionalFoodIds = ['f1', 'f3', 'f5', 'f7', 'f9', 'f11', 'f12'];

// Cosmetics category promotions - expanded selection
const promotionalCosmeticsIds = ['c2', 'c4', 'c6', 'c8', 'c10', 'c12'];

export const shouldShowPromotion = (productId: string) => {
  return (
    promotionalHealthIds.includes(productId) ||
    promotionalFoodIds.includes(productId) ||
    promotionalCosmeticsIds.includes(productId)
  );
};