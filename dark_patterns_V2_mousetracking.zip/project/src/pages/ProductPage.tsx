import React from 'react';
import { useParams } from 'react-router-dom';
import { ShoppingCart, Heart } from 'lucide-react';
import { getProductById } from '../data/products';

export default function ProductPage() {
  const { id } = useParams<{ id: string }>();
  const product = getProductById(id!);

  if (!product) return <div>Product not found</div>;

  return (
    <div className="max-w-7xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="aspect-w-1 aspect-h-1 bg-gray-200 rounded-lg overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-[500px] object-cover"
          />
        </div>
        <div className="flex flex-col">
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-gray-900">{product.name}</h1>
            <p className="mt-4 text-xl text-blue-600 font-semibold">
              ₹{product.price}
            </p>
            <div className="mt-4">
              <h2 className="text-lg font-semibold text-gray-900">Description</h2>
              <p className="mt-2 text-gray-600">{product.details}</p>
            </div>
          </div>
          <div className="mt-8 space-y-4">
            <button className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg flex items-center justify-center space-x-2 hover:bg-blue-700 transition-colors">
              <ShoppingCart className="h-5 w-5" />
              <span>Add to Cart</span>
            </button>
            <button className="w-full border border-gray-300 text-gray-700 py-3 px-6 rounded-lg flex items-center justify-center space-x-2 hover:bg-gray-50 transition-colors">
              <Heart className="h-5 w-5" />
              <span>Add to Wishlist</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}