import React, { createContext, useContext, useState, useCallback } from 'react';
import type { Product } from '../types';

interface CartContextType {
  cartItems: Product[];
  budget: number;
  totalSpent: number;
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  isInCart: (productId: string) => boolean;
  exceedsBudget: (price: number) => boolean;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [cartItems, setCartItems] = useState<Product[]>([]);
  const budget = 5000; // Budget limit in rupees

  const totalSpent = cartItems.reduce((sum, item) => sum + item.price, 0);

  const addToCart = useCallback((product: Product) => {
    setCartItems(prev => [...prev, product]);
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    setCartItems(prev => prev.filter(item => item.id !== productId));
  }, []);

  const isInCart = useCallback((productId: string) => {
    return cartItems.some(item => item.id === productId);
  }, [cartItems]);

  const exceedsBudget = useCallback((price: number) => {
    return totalSpent + price > budget;
  }, [totalSpent, budget]);

  return (
    <CartContext.Provider value={{
      cartItems,
      budget,
      totalSpent,
      addToCart,
      removeFromCart,
      isInCart,
      exceedsBudget
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}