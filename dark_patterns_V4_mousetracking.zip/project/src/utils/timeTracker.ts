let startTime: number | null = null;

export const initializeTimer = () => {
  // Use performance.now() for high-resolution timestamps
  startTime = performance.now();
};

export const getTimecode = (): string => {
  if (!startTime) return '0.000000';
  
  // Get elapsed time with microsecond precision
  const elapsedTime = performance.now() - startTime;
  
  // Convert to seconds and ensure 6 decimal places
  // Use Number to avoid scientific notation
  return Number(elapsedTime / 1000).toFixed(6);
};