import { getTimecode } from './timeTracker';

interface CartInteraction {
  action: 'add' | 'remove';
  productId: string;
  productName: string;
  isPromotional: boolean;
  timestamp: string;
  timecode: string; // seconds.milliseconds
}

let cartInteractions: CartInteraction[] = [];

export const trackCartInteraction = (
  action: 'add' | 'remove',
  productId: string,
  productName: string,
  isPromotional: boolean
) => {
  cartInteractions.push({
    action,
    productId,
    productName,
    isPromotional,
    timestamp: new Date().toISOString(),
    timecode: getTimecode()
  });
};

export const exportToCSV = () => {
  const headers = ['Action', 'Product ID', 'Product Name', 'Is Promotional', 'Timestamp', 'Timecode (seconds)'];
  const csvContent = [
    headers.join(','),
    ...cartInteractions.map(interaction => [
      interaction.action,
      interaction.productId,
      `"${interaction.productName}"`, // Quote the name to handle commas
      interaction.isPromotional,
      interaction.timestamp,
      interaction.timecode
    ].join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', `cart-interactions-${new Date().toISOString()}.csv`);
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};