import React, { useState } from 'react';
import { X } from 'lucide-react';

interface ReflectionProps {
  onComplete: () => void;
  onClose: () => void;
  productName: string;
}

export default function Reflection({ onComplete, onClose, productName }: ReflectionProps) {
  const [reasons, setReasons] = useState({
    pros: ['', ''],
    cons: ['', '']
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (reasons.pros.every(r => r.trim()) && reasons.cons.every(r => r.trim())) {
      onComplete();
    }
  };

  const updateReason = (type: 'pros' | 'cons', index: number, value: string) => {
    setReasons(prev => ({
      ...prev,
      [type]: prev[type].map((r, i) => i === index ? value : r)
    }));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-900">Reflection Time</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <h3 className="font-semibold text-gray-700 mb-3">
              List down 2 reasons why you should buy {productName}:
            </h3>
            {reasons.pros.map((reason, index) => (
              <input
                key={`pro-${index}`}
                type="text"
                value={reason}
                onChange={(e) => updateReason('pros', index, e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg mb-2"
                placeholder={`Reason ${index + 1}`}
                required
              />
            ))}
          </div>

          <div>
            <h3 className="font-semibold text-gray-700 mb-3">
              List down 2 reasons why you shouldn't buy {productName}:
            </h3>
            {reasons.cons.map((reason, index) => (
              <input
                key={`con-${index}`}
                type="text"
                value={reason}
                onChange={(e) => updateReason('cons', index, e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg mb-2"
                placeholder={`Reason ${index + 1}`}
                required
              />
            ))}
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Complete Reflection
          </button>
        </form>
      </div>
    </div>
  );
}