import React from 'react';
import { Download } from 'lucide-react';
import { exportToCSV } from '../utils/mouseTracker';

export default function TrackingControls() {
  return (
    <div className="fixed bottom-4 right-4 z-50">
      <button
        onClick={exportToCSV}
        className="bg-purple-600 text-white p-3 rounded-full shadow-lg hover:bg-purple-700 transition-colors"
        title="Export tracking data"
      >
        <Download className="h-6 w-6" />
      </button>
    </div>
  );
}