import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, Check, AlertCircle } from 'lucide-react';
import type { Product } from '../types';
import { useCart } from '../context/CartContext';
import { getPromotionalValues, shouldShowPromotion } from '../utils/promotions';
import { generateCaptchaText } from '../utils/captcha';
import { trackCartInteraction } from '../utils/mouseTracker';
import Captcha from './Captcha';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart, removeFromCart, isInCart, exceedsBudget } = useCart();
  const [showCaptcha, setShowCaptcha] = useState(false);
  const [captchaText, setCaptchaText] = useState('');

  const handleCartClick = () => {
    const hasPromotion = shouldShowPromotion(product.id);
    
    if (isInCart(product.id)) {
      removeFromCart(product.id);
      trackCartInteraction('remove', product.id, product.name, hasPromotion);
    } else if (!exceedsBudget(product.price)) {
      if (hasPromotion) {
        setCaptchaText(generateCaptchaText());
        setShowCaptcha(true);
      } else {
        addToCart(product);
        trackCartInteraction('add', product.id, product.name, hasPromotion);
      }
    }
  };

  const handleCaptchaSuccess = () => {
    setShowCaptcha(false);
    addToCart(product);
    trackCartInteraction('add', product.id, product.name, true);
  };

  const inCart = isInCart(product.id);
  const wouldExceedBudget = exceedsBudget(product.price);

  const showPromo = shouldShowPromotion(product.id);
  const { discount, stock, isDiscountType } = getPromotionalValues(product.id);

  return (
    <>
      <div className="bg-white rounded-lg shadow-lg overflow-hidden transition-transform hover:scale-105">
        <Link to={`/product/${product.id}`}>
          <div className="relative h-[400px] overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-contain transform hover:scale-110 transition-transform duration-300"
            />
            {showPromo && (
              <div className={`absolute top-4 right-4 px-4 py-2 rounded-lg text-white text-lg font-bold ${isDiscountType ? 'bg-red-500' : 'bg-orange-500'} shadow-lg`}>
                {isDiscountType 
                  ? `${discount}% off Limited time deal!` 
                  : `Only ${stock} left in stock!`}
              </div>
            )}
          </div>
        </Link>
        <div className="p-6">
          <Link to={`/product/${product.id}`}>
            <h3 className="text-xl font-bold text-gray-900 mb-2">{product.name}</h3>
          </Link>
          <p className="text-gray-600 mb-4 line-clamp-2">{product.description}</p>
          <div className="flex items-center justify-between">
            <span className="text-2xl font-bold text-purple-900">
              ₹{product.price}
            </span>
            <button 
              onClick={handleCartClick}
              disabled={!inCart && wouldExceedBudget}
              className={`flex items-center space-x-2 ${
                inCart 
                  ? 'bg-green-500 hover:bg-red-500' 
                  : wouldExceedBudget
                    ? 'bg-gray-400 cursor-not-allowed'
                    : 'bg-purple-600 hover:bg-purple-700'
              } text-white px-4 py-2 rounded-full transition-colors duration-300`}
            >
              {inCart ? (
                <>
                  <Check className="h-5 w-5" />
                  <span>Added - Click to Remove</span>
                </>
              ) : wouldExceedBudget ? (
                <>
                  <AlertCircle className="h-5 w-5" />
                  <span>Exceeds Budget</span>
                </>
              ) : (
                <>
                  <ShoppingCart className="h-5 w-5" />
                  <span>Add to Cart</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
      {showCaptcha && (
        <Captcha
          captchaText={captchaText}
          onSuccess={handleCaptchaSuccess}
          onClose={() => setShowCaptcha(false)}
        />
      )}
    </>
  );
}