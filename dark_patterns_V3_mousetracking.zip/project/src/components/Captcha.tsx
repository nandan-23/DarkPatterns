import React, { useState } from 'react';
import { X } from 'lucide-react';

interface CaptchaProps {
  onSuccess: () => void;
  onClose: () => void;
  captchaText: string;
}

export default function Captcha({ onSuccess, onClose, captchaText }: CaptchaProps) {
  const [input, setInput] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.toLowerCase() === captchaText.toLowerCase()) {
      onSuccess();
    } else {
      setError(true);
      setInput('');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-900">Verify Purchase</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>
        
        <div className="mb-6">
          <p className="text-gray-600 mb-4">
            Please type the text below to confirm your promotional purchase:
          </p>
          <div className="bg-gray-100 p-4 rounded-lg mb-4">
            <p className="text-2xl font-mono text-center select-none" style={{ letterSpacing: '0.25em' }}>
              {captchaText}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            value={input}
            onChange={(e) => {
              setInput(e.target.value);
              setError(false);
            }}
            className={`w-full p-3 border rounded-lg mb-4 ${
              error ? 'border-red-500' : 'border-gray-300'
            }`}
            placeholder="Enter the text above"
            autoFocus
          />
          {error && (
            <p className="text-red-500 text-sm mb-4">
              Incorrect text. Please try again.
            </p>
          )}
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Verify
          </button>
        </form>
      </div>
    </div>
  );
}